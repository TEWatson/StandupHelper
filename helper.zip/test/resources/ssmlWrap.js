'use strict';

module.exports = function(message) {
        return `<speak> ${message} </speak>`
}
