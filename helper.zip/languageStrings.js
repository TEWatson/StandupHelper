module.exports = {
  "strings" : {
    'en': {
      translation: {
        ERROR_MESSAGE: "There was a problem, Taylor probably programmed me wrong",
        NO_LIST_MESSAGE: "No one is late for standup today",
        LIST_MESSAGE_SINGULAR: "Only %s has a standup update so far",
        LIST_MESSAGE_PLURAL: "There are standup updates from these teammates: %s",
        FILL_IN_MESSAGE: "%s"
      },
    }
  }
}
